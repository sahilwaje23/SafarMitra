import React from 'react'

const CaptainSignIn = () => {
  return (
    <div>
      CaptainSignIn
    </div>
  )
}

export default CaptainSignIn
