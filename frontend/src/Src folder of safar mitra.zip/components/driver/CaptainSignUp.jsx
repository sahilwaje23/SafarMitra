import React from 'react'

const CaptainSignUp = () => {
  return (
    <div>CaptainSignUp</div>
  )
}

export default CaptainSignUp