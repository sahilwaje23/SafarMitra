// must be common component to both user and driver

const MapComponent = () => {
    return (
      <>
        
      </>
    )
  }
  
  export default MapComponent;
  