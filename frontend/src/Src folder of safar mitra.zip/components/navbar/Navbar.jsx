// common to both user and driver 
// theme toggling here 

const NavBar = () => {
    return (
      <>
        
      </>
    )
  }
  
  export default NavBar;
  