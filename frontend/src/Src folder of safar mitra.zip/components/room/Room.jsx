// component inside user.jsx

const Room = () => {
    return (
      <>
        
      </>
    )
  }
  
  export default Room;
  